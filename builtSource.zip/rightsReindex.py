import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import text

from lib.dbManager import dbGenerateConnection, importRecord, createSession
from model.rights import Rights
from model.work import Work
from model.instance import Instance
from model.item import Item


def main():
    engine = dbGenerateConnection()

    session = createSession(engine)
    
    works = session.query(Work).all()
    for work in works:
        newRights = Rights.insert({
            'source': 'gutenberg',
            'license': 'https://creativecommons.org/publicdomain/zero/1.0/',
            'statement': 'Public domain in the USA.'
        })

        work.rights.append(newRights)

        for instance in work.instances:
            instance.rights.append(newRights)
            for item in instance.items:
                item.rights.append(newRights)
        
    session.flush()
    session.commit()
    




if __name__ == "__main__":
    os.environ['DB_HOST'] = 'sfr-ebook-metadata-dev.cicyc5fazypj.us-east-1.rds.amazonaws.com'
    os.environ['DB_PORT'] = '5432'
    os.environ['DB_NAME'] =  'sfr'
    os.environ['DB_USER'] = 'sfr'
    os.environ['DB_PASS'] = 'researchnow'
    main()
